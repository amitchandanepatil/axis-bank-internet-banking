package com.axisbank.authservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axisbank.authservice.dto.LoginRequest;
import com.axisbank.authservice.entity.User;
import com.axisbank.authservice.repository.UserRepository;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public User login(LoginRequest request) {

        User user = userRepository.findByUsername(request.getUsername());

        if(user != null &&
           user.getPassword().equals(request.getPassword())) {

            return user;
        }

        return null;
    }
}